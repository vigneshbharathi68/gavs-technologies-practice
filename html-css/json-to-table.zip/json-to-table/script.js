
const table = document.querySelector('#table')
// Set the table header
const url = 'https://jsonplaceholder.typicode.com/posts'

getJsonData()
async function getJsonData() {
    const response = await axios.get(url)    
    const tableHeader = Object.keys(response.data[0])
    // create table header with the keys of the first object in the array
    const thead = document.createElement('thead')
    const tr = document.createElement('tr')
    tableHeader.forEach((item) => {
        const th = document.createElement('th')
        th.innerHTML = item
        tr.appendChild(th)
    })
    thead.appendChild(tr)
    table.appendChild(thead)
    // create table body
    const tbody = document.createElement('tbody')
    table.appendChild(tbody)
    // create table rows with the values of the objects in the array
    response.data.forEach((item) => {
        const tr = document.createElement('tr')
        tableHeader.forEach((key) => {
            const td = document.createElement('td')
            td.innerHTML = item[key]
            tr.appendChild(td)
        })
        tbody.appendChild(tr)
    })
}
